import importlib.util


def package_installation_status(lst):
    """This package tells if the given package is installed in your environment or not
    according to list of name of packages given in the argument ``lst``.

    Parameters
    ----------
        lst (list, positional):
            List containing the name of packages to check if the given package is
            installed in the environment or not.::

    Examples
    --------
    When some of the given packages are installed and some not
    >>> print(package_installation_status(["numpy","pandas","matplotlib","tensorflow"]))
    {'installed_packages': ['numpy', 'pandas'], 'not_installed_packages': ['matplotlib', 'tensorflow']}

    When all the given packages are installed
    >>> print(package_installation_status(["numpy","pandas"]))
    {'installed_packages': ['numpy', 'pandas'], 'not_installed_packages': []}

    When all the given packages are not installed
    >>> print(package_installation_status(["matplotlib","tensorflow"]))
    {'installed_packages': [], 'not_installed_packages': ['matplotlib', 'tensorflow']}


    Raises
    ------
    TypeError
        If `lst` is not list
    ValueError
        If `lst` is empty.

    Examples
    --------
    When input list is empty
    >>> print(package_installation_status([]))
    Traceback (most recent call last):
        File "<stdin>", line 1, in <module>
        File "<stdin>", line 18, in package_installation_status
    ValueError: The list is empty

    When input Parameter is other than list
    >>> print(package_installation_status("pandas"))
    Traceback (most recent call last):
        File "<stdin>", line 1, in <module>
        File "<stdin>", line 20, in package_installation_status
    TypeError: Please provide list as input

    When no input is given
    >>> print(package_installation_status())
    Traceback (most recent call last):
    TypeError: package_installation_status()
    missing 1 required positional argument: 'lst'

    .. note::

        There are no default values if arguments are not given, it will raise TypeError.

    Returns
    -------
    dictonery

    Key1: installed_packages
    Value1: list of all the packages installed in your environment.
    Key2: not_installed_packages
    Value2: list of all the packages installed in your environment.
    """
    if type(lst) == list:
        if len(lst) != 0:
            installed_package_list = []
            unistalled_package_list = []
            for name in lst:
                spec = importlib.util.find_spec(name)
                if spec is None:
                    unistalled_package_list.append(name)
                else:
                    installed_package_list.append(name)
            package_info = {
                "installed_packages": installed_package_list,
                "not_installed_packages": unistalled_package_list,
            }
            return package_info
        else:
            raise ValueError("The list is empty")
    else:
        raise TypeError("Please provide list input")
